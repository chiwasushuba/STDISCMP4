# AnimoRoll · Distributed enrollment portal

A Vite enrollment portal served by a Spring MVC web node, with a thin gRPC API orchestrator and three independently persisted Spring Boot domain services.

## Start here

Requirements: Docker Desktop with Linux containers, Docker Compose 2.24.4+, and Java 21+ for credential setup. The Maven wrapper downloads Maven 3.9.11. Docker builds use Java 21; Java 22 also works for local development.

From PowerShell in this directory:

```powershell
./scripts/setup.ps1
docker compose up -d --build
```

Open **http://localhost:8080**. Docker builds the Vite frontend and packages it in the web application JAR. The first build downloads dependencies and the Node and Java build images. Allow services to finish starting before signing in. Use the retry control if a feature is temporarily unavailable during startup.

Demo accounts:

| Email | Role |
| --- | --- |
| student@northstar.edu | Alex Morgan, student 2024-001 |
| student2@northstar.edu | Sam Rivera, student 2024-002 |
| faculty@northstar.edu | Dr. Jordan Reyes, faculty FAC-001 |

Their shared initial password is the randomly generated **DEMO_PASSWORD** in your local `.env`. Open that file locally to retrieve it. Setup preserves existing keys and credentials. Demo accounts are inserted only when `DEMO_ENABLED=true`; changing the environment password after the account exists does not reset it.

No credentials or private keys belong in source control. The identity service receives the private key. The orchestrator and the three domain services receive the public key to verify tokens. Keep `.env` and `secrets/` with the deployment, outside source archives.

On Linux/macOS, credential setup is `java scripts/GenerateKeys.java`. On Linux Docker hosts, allow the runtime UID to read its private-key mount: `sudo chown 10001:10001 secrets/private.pem` followed by `sudo chmod 600 secrets/private.pem`. The runtime image runs as UID 10001, not root. Windows Docker Desktop handles bind mounts separately.

## Local development

Install Node.js 22.12+ or 24 LTS for local frontend builds. The script builds the Vite frontend, starts the three PostgreSQL containers, and launches five local Java processes.

```powershell
./scripts/setup.ps1
./scripts/run-local.ps1
```

Logs are in `.tools/logs/`; process IDs are recorded in `.tools/local-processes.json`. Stop those Java processes with `./scripts/stop-local.ps1`. Database containers and persistent volumes remain intact. Do not run the local Java stack and the full Docker stack simultaneously: the web port will conflict.

For live frontend changes, keep Spring running on port 8080 from either stack and run:

```powershell
npm --prefix frontend ci
npm --prefix frontend run dev
```

Open **http://127.0.0.1:5173**. Vite proxies `/api` to Spring, so the browser uses a single origin for pages and API requests. In production, Spring serves both on port 8080.

Build a deployable JAR with the frontend included:

```powershell
npm --prefix frontend ci
npm --prefix frontend run build
./mvnw.cmd -B -DskipTests clean package
```

Run the JVM tests independently of the frontend build:

```powershell
./mvnw.cmd -B verify
```

Tests use real PostgreSQL through Testcontainers, so Docker must be running. Testcontainers supplies its own database configuration. On Unix use `sh ./mvnw -B verify`.

Browser checks use Node.js and Playwright as development-only tools. Start the full Docker stack first, then:

```powershell
npm ci
npx playwright install chromium
npm run test:e2e -- --project=journeys
$env:TEST_FAULTS = '1'
npm run test:faults
Remove-Item Env:TEST_FAULTS
```

Fault tests intentionally stop and restart local Docker containers, then check unaffected features and recovery. Run them against the local Docker stack only. They restore stopped containers in `finally` blocks. The journey tests use the synthetic demo accounts and update their enrollment and grade records. Browser captures are written to `.evidence/browser/`. The tests read credentials locally and disable tracing.

Formatting: `npm run format:web:check` checks HTML/CSS/JS. `./mvnw.cmd -B com.spotify.fmt:fmt-maven-plugin:2.29:check` checks Java; use the plugin's `format` goal to apply formatting.

## What is implemented

- Login/logout, signed 15-minute JWT access tokens, persistent eight-hour refresh sessions, rotating refresh tokens, and student/faculty permissions.
- Searchable course catalog, department filtering, open/full/closed states, seat counts, and enrollment receipts.
- Transactional enrollment with duplicate protection and per-course locking to prevent overbooking across service replicas.
- Student-owned historical grades and semester filtering.
- Faculty class rosters, CSV download, upload preview, explicit publish confirmation, and atomic grade updates.
- Independent feature errors, bounded gRPC calls, persistent databases, Flyway migrations, and Hikari connection pooling.
- Responsive student and faculty workspaces with CSRF-protected forms, keyboard focus styling, and no external asset dependency.

CSV format:

```csv
student_id,grade
2024-001,1.25
2024-002,INC
```

Download the selected class roster to get valid student IDs. Blank grades in the downloaded file must be filled or those rows removed before uploading. Maximum upload: 256 KB and 500 rows. This intentionally simple CSV dialect has two unquoted columns; embedded commas and multiline fields are rejected. Allowed grades are 1.00–3.00 in 0.25 steps, 4.00, 5.00, INC, and DRP. A bad value, duplicate student, or unknown roster member rejects the entire publish operation.

## Project layout

```text
contracts/          Versioned protobuf APIs and generated Java stubs
service-common/     JWT validation, RPC security, server lifecycle, error mapping
frontend/           Vite project with plain HTML, CSS, and JavaScript views
web-app/            Spring MVC browser endpoints, sessions, static asset hosting
api-orchestrator/   gRPC controllers forwarding requests to one owning service
identity-service/   Accounts, password verification, JWT signing, refresh sessions
course-service/     Catalog, enrollment, seat allocation
grade-service/      Teaching assignments, rosters, historical and uploaded grades
deployment/         Configuration for separate networked machines
scripts/            Local credentials and process management
docs/               Architecture, deployment, and demonstration guide
tests/              Playwright journeys and service outage checks
deliverables/       Submission source archives, demo video, and slides
```

Each domain service keeps its business rules in `*Service` and exposes them through `*Controller` gRPC handlers. JDBC is used directly rather than adding repositories that only forward identical calls. No service reads another service's tables.

## Fault tolerance and deployment

See [architecture](docs/architecture.md), [networked-machine setup](docs/deployment.md), and [demonstration scenarios](docs/demo.md).

The core design isolates domain failures. It does **not** replicate the web node, orchestrator, or databases. The web node and orchestrator are shared points of failure. Database replication is an optional bonus that has not been implemented; persistence volumes and connection pooling are implemented.

Internal gRPC is plaintext on the private Docker/lab network. The default web listener is HTTP on loopback. For access beyond a trusted demonstration network, configure TLS on the web and gRPC boundaries, enable secure cookies, and provide account provisioning and login throttling before public deployment.

Useful commands:

```powershell
docker compose ps
docker compose logs --tail 80 grade-service
docker compose stop grade-service
docker compose start grade-service
docker compose down
```

`down` preserves the databases. Do not add `--volumes` unless you intend to delete all enrollment, session, and grade data.

## Submission deliverables

The [deliverables folder](deliverables/) contains the demo video, slides, and dated source archives. Run `./scripts/package-source.ps1` to create an `animoroll-source-*.zip` from the current Vite and Spring sources. The archive includes this README, contracts, tests, build scripts, and deployment instructions. It excludes credentials, databases, downloaded tools, dependencies, and build outputs. The recipient runs setup to generate local credentials.
