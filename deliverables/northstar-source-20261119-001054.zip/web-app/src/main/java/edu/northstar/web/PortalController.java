package edu.northstar.web;

import edu.northstar.contracts.*;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.springframework.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class PortalController {
  public static final String TERM = "2026–2027 · Semester 1";
  private static final String PENDING_GRADES = "pendingGrades";
  private final PortalApi api;

  private record GradePreview(String id, GradeUpload upload) {}

  public PortalController(PortalApi api) {
    this.api = api;
  }

  private PortalSession user() {
    return (PortalSession) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
  }

  @GetMapping("/login")
  String loginPage() {
    return "login";
  }

  @PostMapping("/login")
  String login(
      @RequestParam String email,
      @RequestParam String password,
      HttpServletRequest request,
      HttpServletResponse response,
      Model model) {
    try {
      PortalSession session = new PortalSession(api.login(email, password));
      HttpSession previous = request.getSession(false);
      if (previous != null) previous.invalidate();
      var context = SecurityContextHolder.createEmptyContext();
      context.setAuthentication(
          new UsernamePasswordAuthenticationToken(
              session, null, List.of(new SimpleGrantedAuthority("ROLE_" + session.getRole()))));
      SecurityContextHolder.setContext(context);
      new HttpSessionSecurityContextRepository().saveContext(context, request, response);
      return "redirect:/";
    } catch (StatusRuntimeException exception) {
      model.addAttribute("error", message(exception));
      model.addAttribute("email", email);
      return "login";
    }
  }

  @PostMapping("/signout")
  String signout(HttpServletRequest request) {
    boolean revoked = true;
    try {
      api.logout(user());
    } catch (StatusRuntimeException exception) {
      revoked = false;
    }
    request.getSession().invalidate();
    SecurityContextHolder.clearContext();
    return "redirect:/login?signedout" + (revoked ? "" : "&revocationPending");
  }

  @GetMapping("/")
  String dashboard(Model model) {
    if (user().getRole().equals("FACULTY")) return "redirect:/faculty";
    base(model, "dashboard", "Semester overview");
    loadCourses(model, "", "", false);
    loadGrades(model, "");
    return "portal";
  }

  @GetMapping("/courses")
  String courses(
      @RequestParam(defaultValue = "") String search,
      @RequestParam(defaultValue = "") String department,
      Model model) {
    if (!user().getRole().equals("STUDENT")) return "redirect:/faculty";
    base(model, "courses", "Course catalog");
    model.addAttribute("search", search);
    model.addAttribute("department", department);
    loadCourses(model, search, department, false);
    return "portal";
  }

  @GetMapping("/enrollment")
  String enrollment(Model model) {
    if (!user().getRole().equals("STUDENT")) return "redirect:/faculty";
    base(model, "enrollment", "My enrollment");
    loadCourses(model, "", "", true);
    return "portal";
  }

  @PostMapping("/enroll")
  String enroll(@RequestParam String courseId, RedirectAttributes flash) {
    try {
      flash.addFlashAttribute("success", api.enroll(user(), courseId).getMessage());
    } catch (StatusRuntimeException exception) {
      flash.addFlashAttribute("error", message(exception));
    }
    return "redirect:/enrollment";
  }

  @GetMapping("/grades")
  String grades(@RequestParam(defaultValue = "") String term, Model model) {
    if (!user().getRole().equals("STUDENT")) return "redirect:/faculty";
    base(model, "grades", "Grade history");
    // Fetch all owned grades once so filtering never removes semester choices.
    loadGrades(model, "");
    model.addAttribute("selectedTerm", term);
    if (model.getAttribute("grades") instanceof List<?> records) {
      model.addAttribute(
          "grades",
          records.stream()
              .map(Grade.class::cast)
              .filter(g -> term.isEmpty() || g.getTerm().equals(term))
              .toList());
    }
    return "portal";
  }

  @GetMapping("/faculty")
  String faculty(
      @RequestParam(defaultValue = "") String code,
      @RequestParam(defaultValue = "") String term,
      HttpSession session,
      Model model) {
    if (!user().getRole().equals("FACULTY")) return "redirect:/";
    base(model, "faculty", "Classes & grades");
    try {
      var classes = api.classes(user()).getClassesList();
      model.addAttribute("classes", classes);
      TeachingClass selected =
          classes.stream()
              .filter(c -> c.getCourseCode().equals(code) && c.getTerm().equals(term))
              .findFirst()
              .orElse(classes.isEmpty() ? null : classes.getFirst());
      if (selected != null) {
        model.addAttribute("selectedClass", selected);
        model.addAttribute(
            "roster",
            api.roster(user(), selected.getCourseCode(), selected.getTerm()).getGradesList());
        if (session.getAttribute(PENDING_GRADES) instanceof GradePreview pending
            && pending.upload().getCourseCode().equals(selected.getCourseCode())
            && pending.upload().getTerm().equals(selected.getTerm())) {
          model.addAttribute("preview", pending.upload());
          model.addAttribute("previewId", pending.id());
        }
      }
    } catch (StatusRuntimeException exception) {
      model.addAttribute("gradeError", message(exception));
    }
    return "portal";
  }

  @PostMapping("/faculty/preview")
  String preview(
      @RequestParam MultipartFile file,
      @RequestParam String code,
      @RequestParam String term,
      HttpSession session,
      RedirectAttributes flash) {
    PortalSession faculty = user();
    synchronized (faculty) {
      session.removeAttribute(PENDING_GRADES);
      try {
        if (file.isEmpty()) throw new IllegalArgumentException("Choose a non-empty CSV file.");
        GradeUpload upload =
            CsvGrades.parse(new String(file.getBytes(), StandardCharsets.UTF_8), code, term);
        api.roster(faculty, code, term);
        session.setAttribute(
            PENDING_GRADES, new GradePreview(UUID.randomUUID().toString(), upload));
      } catch (IllegalArgumentException exception) {
        flash.addFlashAttribute("error", exception.getMessage());
      } catch (IOException exception) {
        flash.addFlashAttribute("error", "The CSV file could not be read. Choose it again.");
      } catch (StatusRuntimeException exception) {
        flash.addFlashAttribute("error", message(exception));
      }
    }
    flash.addAttribute("code", code);
    flash.addAttribute("term", term);
    return "redirect:/faculty";
  }

  @PostMapping("/faculty/publish")
  String publish(
      @RequestParam(defaultValue = "") String previewId,
      HttpSession session,
      RedirectAttributes flash) {
    PortalSession faculty = user();
    synchronized (faculty) {
      if (!(session.getAttribute(PENDING_GRADES) instanceof GradePreview pending)
          || !pending.id().equals(previewId)) {
        flash.addFlashAttribute(
            "error",
            "This preview is no longer current. Review the latest file before publishing.");
        return "redirect:/faculty";
      }
      GradeUpload upload = pending.upload();
      try {
        flash.addFlashAttribute("success", api.upload(faculty, upload).getMessage());
        session.removeAttribute(PENDING_GRADES);
      } catch (StatusRuntimeException exception) {
        flash.addFlashAttribute("error", message(exception));
      }
      flash.addAttribute("code", upload.getCourseCode());
      flash.addAttribute("term", upload.getTerm());
    }
    return "redirect:/faculty";
  }

  @PostMapping("/faculty/discard")
  String discard(
      @RequestParam(defaultValue = "") String previewId,
      HttpSession session,
      RedirectAttributes flash) {
    synchronized (user()) {
      if (session.getAttribute(PENDING_GRADES) instanceof GradePreview pending
          && pending.id().equals(previewId)) {
        session.removeAttribute(PENDING_GRADES);
        flash.addAttribute("code", pending.upload().getCourseCode());
        flash.addAttribute("term", pending.upload().getTerm());
      } else {
        flash.addFlashAttribute("error", "This preview is no longer current.");
      }
    }
    return "redirect:/faculty";
  }

  @GetMapping("/faculty/template")
  ResponseEntity<String> template(@RequestParam String code, @RequestParam String term) {
    var roster = api.roster(user(), code, term).getGradesList();
    StringBuilder csv = new StringBuilder("student_id,grade\n");
    roster.forEach(
        grade ->
            csv.append(grade.getStudentId()).append(',').append(grade.getValue()).append('\n'));
    return ResponseEntity.ok()
        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=grades.csv")
        .contentType(MediaType.parseMediaType("text/csv;charset=UTF-8"))
        .body(csv.toString());
  }

  private void base(Model model, String page, String title) {
    model.addAttribute("user", user());
    model.addAttribute("page", page);
    model.addAttribute("title", title);
    model.addAttribute("currentTerm", TERM);
  }

  private void loadCourses(Model model, String search, String department, boolean enrolledOnly) {
    try {
      List<Course> courses = api.courses(user(), search, department, enrolledOnly).getCoursesList();
      List<Course> enrolled = courses.stream().filter(Course::getEnrolled).toList();
      model.addAttribute("courses", courses);
      model.addAttribute("enrolled", enrolled);
      model.addAttribute("units", enrolled.stream().mapToInt(Course::getUnits).sum());
      model.addAttribute(
          "openCourses", courses.stream().filter(c -> c.getOpen() && c.getSeats() > 0).count());
    } catch (StatusRuntimeException exception) {
      model.addAttribute("courseError", message(exception));
    }
  }

  private void loadGrades(Model model, String term) {
    try {
      List<Grade> grades = api.grades(user(), term).getGradesList();
      model.addAttribute("grades", grades);
      model.addAttribute("terms", grades.stream().map(Grade::getTerm).distinct().toList());
    } catch (StatusRuntimeException exception) {
      model.addAttribute("gradeError", message(exception));
    }
  }

  static String message(StatusRuntimeException exception) {
    return switch (exception.getStatus().getCode()) {
      case UNAVAILABLE, DEADLINE_EXCEEDED, INTERNAL, UNKNOWN ->
          "This feature is temporarily unavailable. Please try again shortly.";
      default ->
          Optional.ofNullable(exception.getStatus().getDescription())
              .orElse("The request could not be completed.");
    };
  }

  @ExceptionHandler(StatusRuntimeException.class)
  ResponseEntity<String> rpcError(StatusRuntimeException exception) {
    HttpStatus status =
        exception.getStatus().getCode() == Status.Code.PERMISSION_DENIED
            ? HttpStatus.FORBIDDEN
            : HttpStatus.SERVICE_UNAVAILABLE;
    return ResponseEntity.status(status).contentType(MediaType.TEXT_PLAIN).body(message(exception));
  }

  @ExceptionHandler(MaxUploadSizeExceededException.class)
  String oversizedUpload(RedirectAttributes flash) {
    flash.addFlashAttribute("error", "Choose a CSV file no larger than 256 KB.");
    return "redirect:/faculty";
  }
}
