"use strict";
document
  .querySelectorAll("input[type='file'][data-max-bytes]")
  .forEach((input) => {
    input.addEventListener("change", () => {
      const tooLarge = input.files[0]?.size > Number(input.dataset.maxBytes);
      input.setCustomValidity(
        tooLarge ? "Choose a CSV file no larger than 256 KB." : "",
      );
      if (tooLarge) input.reportValidity();
    });
  });

// Server validation remains authoritative; this only prevents accidental repeat clicks.
document.querySelectorAll("form[method='post']").forEach((form) => {
  form.addEventListener("submit", () => {
    const button = form.querySelector("button[type='submit']");
    if (button) {
      button.disabled = true;
      button.textContent = form.hasAttribute("data-enroll-form")
        ? "Enrolling…"
        : "Please wait…";
    }
  });
});
